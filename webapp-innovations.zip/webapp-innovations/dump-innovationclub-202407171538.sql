-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: innovationclub
-- ------------------------------------------------------
-- Server version	8.4.0

/CREATE DATABASE innovationclub;
USE innovationclub;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
 `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `lastName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `course` varchar(100) DEFAULT NULL,
  `points` int DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_logged_in` datetime DEFAULT NULL,
  `privilege` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES (1,'Aditya','Vishnu','aditya.cs21@duk.ac.in','$2a$10$5JSBuMR35YJ/GIDomgvCmuo6UpONl5l7.T3TZK1Qiv3r/k7bJdDxu',NULL,NULL,NULL,'2024-06-09 10:02:12','2024-07-08 22:55:08',0),(2,'Abel','','abel.cs21@duk.ac.in','$2a$10$4XGlff6ngU4XJbemNyi9bO60NDPNsVLltiCNzVT4GFpLX2x8iLr5u',NULL,NULL,NULL,'2024-07-04 17:32:33','2024-07-04 18:13:18',0);
UNLOCK TABLES;



DROP TABLE IF EXISTS `activities`;
CREATE TABLE `activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity_datetime` datetime DEFAULT NULL,
  `description` text,
 --  `points` int DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  -- `status` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
INSERT INTO `activities` VALUES (1,'Expert talk','2024-06-14 14:24:13','2024-06-27 14:00:00','Expert talk on blockchain technology','Test'),(2,'Hackathon','2024-07-07 20:23:20','2024-08-02 10:00:00','DACE Hackathon','Hackathon'),(3,'National Technology Day 2024','2024-07-07 20:26:15','2024-09-07 14:00:00','National technology day celebration','Celebration event'),(18,'SSS','2024-07-07 22:23:33','2024-07-12 05:05:00','sasa','sdsdd'),(19,'AAAa','2024-07-07 22:26:17','2024-07-23 22:22:00','zxzxzx','xzxzxzxzx'),(20,'assaas','2024-07-07 22:32:54','2024-08-01 22:22:00','xzxzxz','asasa'),(21,'ghhhhhh','2024-07-07 22:35:57','2024-07-10 03:03:00','sdfsdsd','33re'),(22,'QQQQQQQ','2024-07-07 22:37:07','2024-07-12 22:21:00','asaa','111111111'),(23,'WWWWWWWW','2024-07-07 22:37:54','2024-07-27 22:20:00','sssssssssssss','ssssssss'),(24,'MUSIC','2024-07-07 22:40:30','2024-07-20 11:11:00','11111111111','1111'),(25,'EARTH','2024-07-07 22:43:37','2024-07-18 12:23:00','222222222','222'),(26,'HEART','2024-07-07 22:44:35','2024-07-18 12:23:00','33','333');
UNLOCK TABLES;






DROP TABLE IF EXISTS `participation_types`;
CREATE TABLE `participation_types`(
`id` int NOT NULL AUTO_INCREMENT,
`activity_id` int NOT NULL,
`type` varchar(100) NOT NULL,
`point` int NOT NULL,
PRIMARY KEY (`id`),
FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`)
);

DROP TABLE IF EXISTS `attendance_applications`;
CREATE TABLE `attendance_applications` (
`id` int NOT NULL AUTO_INCREMENT,
`user_id` INT,
`user_email` VARCHAR(100),
`activity_id` INT,
`activity_name`varchar(100), 
`participation_type` VARCHAR(100) NOT NULL,
`points` INT,
`status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
PRIMARY KEY (`id`),
FOREIGN KEY (`user_id`) REFERENCES `users`(`id`),
FOREIGN KEY (`activity_id`) REFERENCES `activities`(`id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;